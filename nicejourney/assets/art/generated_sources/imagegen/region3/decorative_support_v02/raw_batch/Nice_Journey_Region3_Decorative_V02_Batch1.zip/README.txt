Nice Journey - Region 3 Decorative V02 - Batch 1
Contains 10 generated source PNGs for decorative buildings 01-10.
Do not treat these as integrated production assets until source intake, derivation, provenance, renderer review, and regression are complete.
